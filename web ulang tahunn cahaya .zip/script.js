// ==== DATA TEKA-TEKI ====
const riddleAnswer = "di hatimu"; // Jawaban teka-teki

// ==== PESAN AKHIR ====
const finalMessageText = `
Selamat ulang tahun! 🎉

Hari ini adalah hari yang istimewa, bukan hanya karena kamu bertambah usia, tapi juga karena kamu sudah sejauh ini melangkah dalam hidup. Kamu sudah melewati banyak hal — tawa, tangis, perjuangan, bahkan rasa lelah yang mungkin membuatmu hampir menyerah. Tapi lihatlah dirimu sekarang, masih berdiri, masih berjuang, dan masih punya harapan. Itu bukti betapa kuatnya kamu! 💪✨

Di usia baru ini, semoga kamu selalu diberi kesehatan, rezeki yang lancar, dan kebahagiaan yang tidak pernah habis. Jangan pernah ragu untuk bermimpi besar, karena dunia ini terlalu luas untuk kamu jalani dengan rasa takut. Ingat, gagal itu biasa, jatuh itu wajar, tapi bangkit lagi itulah yang membuatmu luar biasa. 🔥

Selamat bertambah usia! 🌟 Hidup ini layak dijalani dengan penuh cinta, semangat, dan harapan. Masa depanmu begitu cerah dan menunggumu untuk menjemputnya. ✨💖
`;

// ==== TAMPILKAN SECTION ====
function showSection(id) {
  document.querySelectorAll('.section').forEach(section => {
    section.classList.remove('active');
  });
  document.getElementById(id).classList.add('active');
}

// ==== LOGIKA ADMIN ====
window.toggleAdminPanel = function() {
  const adminPanel = document.getElementById('admin-panel');
  const mainSections = document.querySelectorAll('#riddle-section, #game-section, #final-section');
  const button = document.getElementById('admin-toggle-button');
  
  if (adminPanel.classList.contains('active')) {
    adminPanel.classList.remove('active');
    mainSections.forEach(section => section.style.display = 'block');
    button.textContent = 'Buka Halaman Admin';
    showSection('riddle-section');
  } else {
    adminPanel.classList.add('active');
    mainSections.forEach(section => section.style.display = 'none');
    button.textContent = 'Tutup Halaman Admin';
  }
};

const photoUpload = document.getElementById('photo-upload');
const photoPreview = document.getElementById('photo-preview');
const statusMessage = document.getElementById('status-message');

photoUpload.addEventListener('change', function(e) {
  const file = e.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = ev => {
      photoPreview.src = ev.target.result;
      photoPreview.style.display = 'block';
    };
    reader.readAsDataURL(file);
  }
});

window.uploadPhoto = function() {
  const file = photoUpload.files[0];
  if (!file) {
    statusMessage.textContent = 'Pilih foto dulu, ya!';
    statusMessage.style.color = '#e74c3c';
    return;
  }
  
  let savedPhotos = JSON.parse(localStorage.getItem('savedPhotos')) || [];
  if (savedPhotos.length >= 3) {
    statusMessage.textContent = 'Maksimal 3 foto sudah diunggah.';
    statusMessage.style.color = '#e74c3c';
    photoUpload.value = '';
    photoPreview.style.display = 'none';
    return;
  }
  
  const reader = new FileReader();
  reader.onload = e => {
    savedPhotos.push(e.target.result);
    localStorage.setItem('savedPhotos', JSON.stringify(savedPhotos));
    statusMessage.textContent = `Foto berhasil diunggah! (${savedPhotos.length}/3)`;
    statusMessage.style.color = '#2ecc71';
    photoUpload.value = '';
    photoPreview.style.display = 'none';
  };
  reader.readAsDataURL(file);
};

window.resetPhotos = function() {
  localStorage.removeItem('savedPhotos');
  statusMessage.textContent = 'Semua foto berhasil di-reset!';
  statusMessage.style.color = '#3498db';
  photoUpload.value = '';
  photoPreview.style.display = 'none';
};

// ==== LOGIKA CERITA ====
window.checkRiddle = function() {
  const answer = document.getElementById('riddle-answer').value.toLowerCase().trim();
  if (answer === riddleAnswer) {
    alert("Jawabanmu benar! 🎉");
    createGameGrid();
    showSection('game-section');
  } else {
    alert("Jawaban salah, coba lagi 😅");
  }
};

function createGameGrid() {
  const gameGrid = document.getElementById('game-grid');
  gameGrid.innerHTML = '';
  const keyIndex = Math.floor(Math.random() * 9);
  
  for (let i = 0; i < 9; i++) {
    const item = document.createElement('div');
    item.classList.add('game-item');
    item.textContent = '🎁';
    
    item.onclick = () => {
      if (i === keyIndex) {
        item.textContent = '🔑';
        item.style.backgroundColor = '#2ecc71';
        document.getElementById('game-message').textContent = 'Kamu menemukan kunci hatiku! 💖';
        setTimeout(() => {
          loadPhotos();
          showSection('final-section');
        }, 1500);
      } else {
        item.textContent = '💔';
        item.style.backgroundColor = '#e74c3c';
        document.getElementById('game-message').textContent = 'Bukan di sini...';
      }
    };
    gameGrid.appendChild(item);
  }
}

function loadPhotos() {
  const photoGrid = document.getElementById('photo-grid');
  const savedPhotos = JSON.parse(localStorage.getItem('savedPhotos')) || [];
  photoGrid.innerHTML = '';
  
  if (savedPhotos.length === 0) {
    photoGrid.innerHTML = '<p>Belum ada foto diunggah. Silakan unggah di halaman admin.</p>';
    return;
  }
  
  savedPhotos.forEach(photoData => {
    const img = document.createElement('img');
    img.src = photoData;
    img.alt = 'Kenangan';
    img.onclick = () => {
      document.querySelectorAll('#photo-grid img').forEach(p => {
        p.style.opacity = '0';
        p.style.transform = 'scale(0.8)';
      });
      setTimeout(showFinalMessage, 600);
    };
    photoGrid.appendChild(img);
  });
}

function showFinalMessage() {
  const finalMessageDiv = document.getElementById('final-message');
  finalMessageDiv.innerHTML = `<p></p>`;
  finalMessageDiv.classList.remove('hidden');
  
  const textElement = finalMessageDiv.querySelector('p');
  let index = 0;
  
  function typeWriter() {
    if (index < finalMessageText.length) {
      textElement.innerHTML += finalMessageText.charAt(index);
      index++;
      setTimeout(typeWriter, 30); // Kecepatan ketikan
    } else {
      // Musik mulai setelah selesai ngetik
      const music = document.getElementById('background-music');
      music.play().catch(() => {});
    }
  }
  typeWriter();
  
  finalMessageDiv.scrollIntoView({ behavior: 'smooth' });
}